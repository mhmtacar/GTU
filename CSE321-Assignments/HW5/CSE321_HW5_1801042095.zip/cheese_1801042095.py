def find_max_price(price,weight,capacity,n):

    total_weight=0
    max_price=0

    pricePerWeight = []
    for i in range(n):
        pricePerWeight.append(price[i]/weight[i])

    pricePerWeight_order=[] 
    for i in range(n):
        pricePerWeight_order.append(pricePerWeight.index(max(pricePerWeight)))
        pricePerWeight[pricePerWeight.index(max(pricePerWeight))]=0

    i=0
    
    while total_weight!=capacity:
        if capacity<(total_weight+weight[pricePerWeight_order[i]]):
            fraction = (capacity-total_weight)/weight[pricePerWeight_order[i]]
            value = price[pricePerWeight_order[i]]*fraction
            max_price+= value
            total_weight+=(capacity-total_weight)
            
        else:
            max_price+=price[pricePerWeight_order[i]]
            total_weight+=weight[pricePerWeight_order[i]]
            
        i+=1

    return max_price


#Driver Code
price= [80,60,120,140]
weight= [20,50,30,40]
capacity=70
size=len(price)
print("Maximum price is", find_max_price(price,weight,capacity,size))
