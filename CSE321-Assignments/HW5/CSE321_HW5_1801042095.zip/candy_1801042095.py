def cutCandy(price, n):
    
    obtVal = [0 for x in range(n+1)]
    obtVal[0] = 0
    INT_MIN = -1000
    
    for i in range(1, n+1):
        maxVal = INT_MIN
        for j in range(i):
             maxVal = max(maxVal, price[j] + obtVal[i-j-1])
        obtVal[i] = maxVal

    return obtVal[n]

# Driver Code
price = [1, 5, 8, 9, 10, 17, 17, 20]
size = len(price)
print("Maximum Obtainable Value is " + str(cutCandy(price, size)))


