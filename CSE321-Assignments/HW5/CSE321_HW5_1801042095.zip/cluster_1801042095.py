def maxProfit(A,n):
    
    max_till_now = 0
    max_ending = 0
    
    for i in range(0, n):
        
        max_ending = max_ending + A[i]
        
        if max_ending < 0:
            max_ending = 0
        
        if (max_till_now < max_ending):
            max_till_now = max_ending
            
    return max_till_now


# Driver Code
A = [3, -5, 2, 11, -8, 9, -5]
size_A = len(A) 
print("Maximum profit is" , maxProfit(A,size_A))
