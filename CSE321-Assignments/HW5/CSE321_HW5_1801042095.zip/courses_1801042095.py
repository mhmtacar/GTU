def find_MaxCourseNum(start , finish , n):
    
    i = 0
    maxCourseNum = 1

    for j in range(n):

        if start[j] >= finish[i]:
            maxCourseNum+=1
            i = j

    return maxCourseNum

# Driver Code
start = [1 , 3 , 0 , 5 , 8 , 5]
finish = [2 , 4 , 6 , 7 , 9 , 9]
size = len(finish)
print("Maximum number of courses a student can attend:", find_MaxCourseNum(start , finish , size))

