
def RopNum(arr, n):
    temp_arr = [0]*n
    return _RopNum(arr, temp_arr, 0, n-1)


def _RopNum(arr, temp_arr, left, right):

    rop_count = 0

    if left < right:

        mid = (left + right)//2

        rop_count += _RopNum(arr, temp_arr,
                             left, mid)
        
        rop_count += _RopNum(arr, temp_arr,
                             mid + 1, right)
        
        rop_count += merge(arr, temp_arr, left, mid, right)
        
    return rop_count


def merge(arr, temp_arr, left, mid, right):
    
    i = left     
    j = mid + 1  
    k = left     
    rop_count = 0

    while i <= mid and j <= right:

        if arr[i] > arr[j]:
            temp_arr[k] = arr[j]
            rop_count += (mid-i + 1)
            j += 1
            k += 1
            
        else:
            temp_arr[k] = arr[i]
            i += 1
            k += 1

    while i <= mid:
        temp_arr[k] = arr[i]
        i += 1
        k += 1

    while j <= right:
        temp_arr[k] = arr[j]
        j += 1
        k += 1

    for loop_var in range(left, right + 1):
        arr[loop_var] = temp_arr[loop_var]

    return rop_count


# Driver Code

arr = [3,7,5,2,8,4,9]
n = len(arr)
print("The number of reverse-ordered pairs is", RopNum(arr, n))

