def exponentiation_BruteForce(base,exponent):

    result = 1
    
    for i in range(exponent):
        result*=base
        
    return result


def exponentiation_DivConq(base,exponent):
    
    if (exponent == 0): 
        return 1
    
    result = exponentiation_DivConq(base, int(exponent / 2))
    
    if (int(exponent % 2) == 0):
        return result * result
    
    else:
        return base * result * result


#Driver Code
base=3
exponent=2
print(base, "^", exponent, "=", exponentiation_BruteForce(base, exponent))
print(base, "^", exponent, "=", exponentiation_DivConq(base, exponent))
