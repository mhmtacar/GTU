def min_cut(num,count):
    
    if(num <= 1):
        return count
    
    else:
        return min_cut(float(num/2), count+1)

#Driver Code
number = 33
print("The minimum number of cuts for " + str(number) + " is "+ str(min_cut(number, 0)))


