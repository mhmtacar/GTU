def success_rate(arr, left, right, k):
 
    if (k > 0):

        if(right-left >= k-1):
 
            num = arr[right]
            i = left
            
            for j in range(left, right):
             
                if arr[j] <= num:
                    arr[i], arr[j] = arr[j], arr[i]
                    i += 1
                 
            arr[i], arr[right] = arr[right], arr[i]

            index = i

            if(k - 1 > index - left):
                return success_rate(arr, index + 1, right,
                                    k - index + left - 1)

            elif (k - 1 == index - left):
                return arr[index]
     
            else:
                return success_rate(arr, left, index - 1, k)

            


#Driver Code
    
experiment_results = [ 3,7,5,2,8,4,9 ]
n = len(experiment_results)
k = 4
print("The success rate of the first meaningful", k, "th experiment is", success_rate(experiment_results,0,n-1,k))
