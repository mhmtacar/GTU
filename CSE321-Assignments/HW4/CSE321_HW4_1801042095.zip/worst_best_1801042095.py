import sys
 
def worst_best(arr, left, right, min=sys.maxsize, max=-sys.maxsize):
 
    if left == right:               

        if max < arr[left]:           
            max = arr[left]
            
        if min > arr[right]:          
            min = arr[right]
 
        return max,min
    
 
    elif right == left + 1:           
 
        if arr[left] >= arr[right]:

            if max < arr[left]:       
                max = arr[left]

            if min > arr[right]:   
                min = arr[right]
            
        else:

            if max < arr[right]:      
                max = arr[right]

            if min > arr[left]:       
                min = arr[left]
            
        return max, min

    else:
 
        mid = (left + right) // 2
 
        max, min = worst_best(arr, left, mid, min, max)
 
        max, min = worst_best(arr, mid + 1, right, min, max)
 
        return max, min
 
 
if __name__ == '__main__':
 
    experiment_results = [3,7,5,2,8,4,9]
    length = len(experiment_results)
 
    (max, min) = worst_best(experiment_results, 0, length - 1)

    print("The worst result of experiment is", max)
    print("The best result of experiment is ", min)
