def polynomial_value(coefficient, length_coefficient, x):

    value = 0
 
    for i in range(0, length_coefficient):

        power = 1

        for j in range(0, i):
            power *= x

        value += coefficient[i]*power


    return value


# Driver Code

# coefficient array's first index contains x^0 coefficient, second index contains x^1 coefficient and continue like that
coefficient = [9, 7, 2, 3]  # -> P(x) = 3x^3 + 2x^2 + 7x + 9
length_coefficient = len(coefficient)
x = 2

print("Value of polynomial at x =", x, "is :", polynomial_value(coefficient, length_coefficient, x))  # - > value = 3(2^3) + 2(2^2) + 7*2 + 9 = 55
