
def maxMidProfit(A, left, middle, right, left_sum, right_sum, summation):

	for i in range(middle, left-1, -1):
            
		summation += A[i]

		if (summation > left_sum):
			left_sum = summation

	summation = 0

	for i in range(middle + 1, right + 1):
		summation += A[i]

		if (summation > right_sum):
			right_sum = summation

	return max(left_sum, right_sum, left_sum + right_sum)


def maxProfit(A, left, right):

	if (left == right):
		return A[left]

	middle = (left + right) // 2

	return max(maxMidProfit(A, left, middle, right, 0, 0, 0),
                   maxProfit(A, left, middle),
		   maxProfit(A, middle+1, right))


# Driver Code
A = [3, -5, 2, 11, -8, 9, -5]
size_A = len(A)

print("Maximum profit is ", maxProfit(A, 0, size_A-1))

