def numOfSubstr(str, a, b, length_str):
 
    num_a = 0
    
    num_Substr = 0
 
    for i in range(length_str):
 
        if str[i] == a:
            num_a += 1
 
        if str[i] == b:
            num_Substr += num_a

    return num_Substr

 
# Driver Code
str = 'TXZXXJZWX'
a = 'X'
b = 'Z'
length_str = len(str)
print("Num of substrings that starts with character", a, "and ends with character", b, ":", numOfSubstr(str, a, b, length_str))
